Feathercoin
===========

 - 1 minute block targets
 - 80 coins per block
 - NeoScrypt hashing algorithm
 - Retarget every block
 - Retarget with average of 15, 120 and 480 block averages and .25 damping
 - Subsidy halves every ~4 years
 - ~336 million total coins
 
Official Wesbite and Downloads
==============================

https://www.feathercoin.com/
